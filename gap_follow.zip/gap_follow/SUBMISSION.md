# Lab 4: Follow the Gap

## YouTube video link
[https://youtu.be/vFxciqGSK80](Levine_blocked Map)

[https://youtu.be/Pq3HxCfhl7c](Levine_obs Map)
#the car cannot do the whole run, it does have some avoidance action, however, it cannot completely avoid the collision of obstacles. The main reason is the forward looking distance, as it has to be traded-off between response time and responce distance. 
