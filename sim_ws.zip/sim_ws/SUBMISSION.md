# Lab 2: Automatic Emergency Braking

## YouTube video link
[https://youtu.be/uqvQNuZdznA]
