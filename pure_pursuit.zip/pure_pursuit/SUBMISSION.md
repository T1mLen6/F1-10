# Lab 6: SLAM and Pure Pursuit

## YouTube video link
[https://youtu.be/p-DNvOxnJ54]
