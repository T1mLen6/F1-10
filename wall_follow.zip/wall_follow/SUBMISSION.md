# Lab 3: Wall Following

## YouTube video links
Simulator (individual) : [https://youtu.be/5oTW5TJjQlM]

Hardware (group) : [FILL ME IN](https://tinyurl.com/22mts2ax)
